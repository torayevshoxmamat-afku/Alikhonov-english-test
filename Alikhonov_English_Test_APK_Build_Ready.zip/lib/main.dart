import 'package:flutter/material.dart';

void main() => runApp(const AlikhonovApp());

class Question {
  final String text;
  final List<String> options;
  final int answer;
  const Question(this.text, this.options, this.answer);
}

const questions = [
  Question("She ___ to school every day.", ["go", "goes", "going", "gone"], 1),
  Question("I have lived here ___ 2022.", ["for", "since", "from", "at"], 1),
  Question("If I had more time, I ___ more books.", ["read", "will read", "would read", "am reading"], 2),
  Question("Choose the synonym of 'rapid'.", ["slow", "quick", "weak", "late"], 1),
  Question("They ___ dinner when I arrived.", ["have", "had", "were having", "are having"], 2),
  Question("There isn't ___ milk in the fridge.", ["many", "some", "any", "few"], 2),
  Question("He is interested ___ learning English.", ["on", "in", "at", "for"], 1),
  Question("This is the ___ movie I have ever seen.", ["good", "better", "best", "well"], 2),
  Question("You ___ wear a seat belt in a car.", ["should", "can", "might", "would"], 0),
  Question("The opposite of 'ancient' is ___", ["modern", "old", "historic", "early"], 0),
];

class AlikhonovApp extends StatelessWidget {
  const AlikhonovApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Alikhonov English Test',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF1769AA)),
        scaffoldBackgroundColor: const Color(0xFFF5F8FC),
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Alikhonov English Test")),
      body: Padding(
        padding: const EdgeInsets.all(22),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const SizedBox(height: 28),
            const Icon(Icons.school_rounded, size: 82, color: Color(0xFF1769AA)),
            const SizedBox(height: 18),
            const Text("English Test",
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            const Text("Grammar va Vocabulary bo‘yicha bilimingizni sinang.",
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 16, color: Colors.black54)),
            const SizedBox(height: 36),
            FilledButton.icon(
              icon: const Icon(Icons.play_arrow_rounded),
              label: const Padding(
                padding: EdgeInsets.symmetric(vertical: 14),
                child: Text("Testni boshlash", style: TextStyle(fontSize: 18)),
              ),
              onPressed: () {
                Navigator.push(context,
                  MaterialPageRoute(builder: (_) => const TestPage()));
              },
            ),
            const SizedBox(height: 14),
            OutlinedButton.icon(
              icon: const Icon(Icons.info_outline),
              label: const Text("Ilova haqida"),
              onPressed: () => showAboutDialog(
                context: context,
                applicationName: "Alikhonov English Test",
                applicationVersion: "1.0.0",
                children: const [
                  Text("English Grammar va Vocabulary testlari uchun mobil ilova.")
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class TestPage extends StatefulWidget {
  const TestPage({super.key});
  @override State<TestPage> createState() => _TestPageState();
}

class _TestPageState extends State<TestPage> {
  int current = 0;
  int score = 0;
  int? selected;

  void next() {
    if (selected == null) return;
    if (selected == questions[current].answer) score++;
    if (current == questions.length - 1) {
      Navigator.pushReplacement(context, MaterialPageRoute(
        builder: (_) => ResultPage(score: score, total: questions.length),
      ));
    } else {
      setState(() {
        current++;
        selected = null;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final q = questions[current];
    return Scaffold(
      appBar: AppBar(
        title: Text("Savol ${current + 1}/${questions.length}"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            LinearProgressIndicator(value: (current + 1) / questions.length),
            const SizedBox(height: 28),
            Text(q.text,
                style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w700)),
            const SizedBox(height: 22),
            ...List.generate(q.options.length, (i) {
              return Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: ChoiceChip(
                  label: SizedBox(
                    width: double.infinity,
                    child: Text("${String.fromCharCode(65+i)}. ${q.options[i]}"),
                  ),
                  selected: selected == i,
                  onSelected: (_) => setState(() => selected = i),
                  padding: const EdgeInsets.all(12),
                ),
              );
            }),
            const Spacer(),
            FilledButton(
              onPressed: selected == null ? null : next,
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Text(current == questions.length - 1 ? "Natijani ko‘rish" : "Keyingi"),
              ),
            )
          ],
        ),
      ),
    );
  }
}

class ResultPage extends StatelessWidget {
  final int score, total;
  const ResultPage({super.key, required this.score, required this.total});

  @override
  Widget build(BuildContext context) {
    final percent = (score / total * 100).round();
    String level = percent >= 90 ? "C1" : percent >= 75 ? "B2" : percent >= 60 ? "B1" : percent >= 40 ? "A2" : "A1";
    return Scaffold(
      appBar: AppBar(title: const Text("Natija")),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.emoji_events_rounded, size: 90, color: Color(0xFF1769AA)),
              const SizedBox(height: 20),
              const Text("Test yakunlandi!", style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
              const SizedBox(height: 14),
              Text("$score / $total", style: const TextStyle(fontSize: 42, fontWeight: FontWeight.w800)),
              Text("$percent%", style: const TextStyle(fontSize: 20)),
              const SizedBox(height: 12),
              Text("Taxminiy daraja: $level", style: const TextStyle(fontSize: 20)),
              const SizedBox(height: 35),
              FilledButton(
                onPressed: () => Navigator.pushReplacement(
                  context, MaterialPageRoute(builder: (_) => const HomePage())),
                child: const Padding(
                  padding: EdgeInsets.symmetric(horizontal: 35, vertical: 14),
                  child: Text("Bosh sahifaga qaytish"),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
