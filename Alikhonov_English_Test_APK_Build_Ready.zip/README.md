# Alikhonov English Test

Flutter asosidagi Android/iOS MVP.

## Ishga tushirish
1. Flutter SDK va Android Studio o‘rnating.
2. Terminalda loyiha papkasiga kiring.
3. `flutter pub get`
4. `flutter run`

## Release
Android:
`flutter build appbundle --release`

iOS (macOS + Xcode kerak):
`flutter build ipa --release`

Keyingi bosqichlarda savollarni JSON/Firebase orqali boshqarish, login, statistika, reklama/Premium va admin panel qo‘shish mumkin.

## Muhim
Ilova store'ga chiqarilishidan oldin package/bundle ID, app icon, privacy policy, screenshots va store metadata tayyorlanadi.
